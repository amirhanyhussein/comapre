class AppLanguages {
  //
  static List<String> get codes => [
        "en",
        "ar",
        "fr",
        "es",
        "ko",
        "de",
        "pt",
        "hi",
        "tr",
        "ru",
        "my",
        "zh",
        "ja"
      ];

  static List<String> get names => [
        "English",
        "Arabic",
        "French",
        "Spanish",
        "Korean",
        "German",
        "Portuguese",
        "Hindi",
        "Turkish",
        "Russian",
        "Myanmar",
        "Chinese",
        "Japanese"
      ];

  static List<String> get flags => [
        "GB",
        "EG",
        "FR",
        "ES",
        "KR",
        "DE",
        "PT",
        "IN",
        "TR",
        "RU",
        "MY",
        "CN",
        "JP"
      ];

  static List<String> get flagsForHome => [
        "EG",
        "SA",
        "DZ",
        "MA",
        "TN",
        "LY",
        "JO",
        "IQ",
        "SY",
        "LB",
        "PS",
        "KW",
        "BH",
        "QA",
        "AE",
        "OM",
        "YE",
        "IT",
        "US",
        "RU",
        "FR",
      ];

  static List<String> get countryCodesForHome => [
        "20", // Egypt
        "966", // Saudi Arabia
        "213", // Algeria
        "212", // Morocco
        "216", // Tunisia
        "218", // Libya
        "962", // Jordan
        "964", // Iraq
        "963", // Syria
        "961", // Lebanon
        "970", // Palestine
        "965", // Kuwait
        "973", // Bahrain
        "974", // Qatar
        "971", // United Arab Emirates
        "968", // Oman
        "967", // Yemen
        "39", // Italy
        "1", // United States
        "7", // Russia
        "33", // France
      ];

  static List<String> get countriesForHome => [
        "Egypt",
        "Saudi Arabia",
        "Algeria",
        "Morocco",
        "Tunisia",
        "Libya",
        "Jordan",
        "Iraq",
        "Syria",
        "Lebanon",
        "Palestine",
        "Kuwait",
        "Bahrain",
        "Qatar",
        "United Arab Emirates",
        "Oman",
        "Yemen",
        "Italy",
        "United States",
        "Russia",
        "France",
      ];
}
