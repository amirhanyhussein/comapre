import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:fuodz/view_models/product_details.vm.dart';
import 'package:fuodz/widgets/buttons/custom_outline_button.dart';

class ProductFavButton extends StatelessWidget {
  const ProductFavButton({
    required this.model,
    Key? key,
  }) : super(key: key);

  final ProductDetailsViewModel model;

  @override
  Widget build(BuildContext context) {
    return CustomOutlineButton(
      loading: model.isBusy,
      color: Colors.transparent,
      child: FaIcon(
        (!model.isAuthenticated() || !model.product.isFavourite)
            ? FontAwesomeIcons.heart
            : FontAwesomeIcons.solidHeart,
        color: Colors.red,
      ),
      onPressed: !model.isAuthenticated()
          ? model.openLogin
          : !model.product.isFavourite
              ? model.addToFavourite
              : model.removeFromFavourite,
    );
  }
}
