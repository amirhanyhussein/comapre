import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:fuodz/constants/app_colors.dart';
import 'package:fuodz/utils/utils.dart';
import 'package:fuodz/view_models/taxi_new_order_location_entry.vm.dart';
import 'package:localize_and_translate/localize_and_translate.dart';
import 'package:velocity_x/velocity_x.dart';

class NewTaxiPickOnMapButton extends StatelessWidget {
  const NewTaxiPickOnMapButton({
    Key? key,
    required this.taxiNewOrderViewModel,
  }) : super(key: key);

  final NewTaxiOrderLocationEntryViewModel taxiNewOrderViewModel;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: taxiNewOrderViewModel.showChooseOnMap,
      child: HStack(
        [
          FaIcon(
            FontAwesomeIcons.map ,
            color: AppColor.primaryColor,
          ),
          "Choose a place on the map"
              .tr()
              .text
              .lg
              .medium
              .make()
              .px16()
              .expand(),
          Icon(
            Utils.isArabic
                ? FontAwesomeIcons.chevronLeft
                : FontAwesomeIcons.chevronRight,
            color: Colors.grey.shade300,
          )
        ],
      )
          .safeArea(top: false)
          .p12()
          .box
          .color(Utils.textColorByBrightness(context, true))
          .shadowSm
          .make()
          .onInkTap(taxiNewOrderViewModel.handleChooseOnMap),
    );
  }
}
