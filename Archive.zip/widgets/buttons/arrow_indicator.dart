import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:fuodz/utils/utils.dart';

class ArrowIndicator extends StatelessWidget {
  const ArrowIndicator(this.size, {Key? key}) : super(key: key);

  final double? size;
  @override
  Widget build(BuildContext context) {
    return FaIcon(
      Utils.isArabic
          ? FontAwesomeIcons.chevronLeft
          : FontAwesomeIcons.chevronRight,
      size: size ?? 32,
    );
  }
}
